import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  metadataBase:new URL("https://intelligent-audio-effects.fluffy-fern-4625.chatgpt.site"),
  title:"Intelligent Audio Production",
  description:"An open map of research, projects and evaluation resources for intelligent audio effects, mixing and mastering.",
  icons:{icon:"/favicon.svg",shortcut:"/favicon.svg"},
  openGraph:{title:"Intelligent Audio Production",description:"Understanding and shaping how music sounds.",type:"website",images:["/og.png"]},
  twitter:{card:"summary_large_image",title:"Intelligent Audio Production",description:"Understanding and shaping how music sounds.",images:["/og.png"]},
};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
