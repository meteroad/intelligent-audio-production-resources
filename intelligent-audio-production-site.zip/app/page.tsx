const areas = [
  ["01","Representation","Learn how audio changes—not only how it sounds after processing.",["RelFx","AudioDelta","Effect embeddings"]],
  ["02","Mixing","Systems for balancing, shaping and blending multitrack music.",["Automatic mixing","Reference-guided","Stem blending"]],
  ["03","Mastering","Intelligent control of loudness, dynamics and tonal balance.",["Style transfer","Loudness","Dynamics"]],
  ["04","Evaluation","Reproducible benchmarks and perceptually grounded production metrics.",["MixBench","MixCritic","Listening tests"]],
  ["05","Spatial Audio","A future track for spatial rendering, positioning and immersive production.",["Spatial mixing","Rendering","Immersive audio"]],
] as const;
const resources = [
  ["Open-source Index","Landscape","Building","A structured map of code, models, datasets and tools across intelligent audio production."],
  ["MixBench","Benchmark","Planned","A fixed and reproducible evaluation protocol for automatic music mixing."],
  ["RelFx","Representation","Research","Relative audio-effects representations that model production changes without a dry reference."],
] as const;

export default function Home() {
  return <main>
    <header className="site-header">
      <a className="identity" href="#top"><span className="mark">IA</span><span>Intelligent Audio Production</span></a>
      <nav><a href="#map">Field map</a><a href="#resources">Resources</a><a href="#roadmap">Roadmap</a></nav>
      <a className="profile-link" href="#about">Xinlu Liu ↗</a>
    </header>

    <section className="hero" id="top">
      <div><p className="eyebrow"><span/> Open research index · 2026</p>
        <h1>Understanding and shaping<br/><em>how music sounds.</em></h1>
        <p className="lede">A living map of research, open-source projects and evaluation resources for intelligent audio effects, mixing, mastering and beyond.</p>
        <div className="hero-actions"><a className="button primary" href="#map">Explore the field <span>↓</span></a><a className="button quiet" href="#resources">View resources</a></div>
      </div>
      <div className="signal">
        <div className="signal-label"><span>CONTENT</span><span>CHANGE</span><span>RESULT</span></div>
        <svg viewBox="0 0 620 250" role="img" aria-label="Audio waveform transformed into a production representation">
          <path className="wave" d="M5 132C20 132 21 95 35 95s15 69 30 69S82 63 98 63s16 128 32 128 15-90 30-90 18 50 33 50 13-29 27-29"/>
          <path className="connector" d="M230 126h150"/><circle cx="270" cy="126" r="6"/><circle cx="310" cy="126" r="6"/><circle cx="350" cy="126" r="6"/>
          <path className="wave result" d="M390 132c15 0 16-56 30-56s15 104 30 104 17-83 33-83 16 62 32 62 15-48 30-48 18 32 33 32 13-17 32-17"/>
        </svg><div className="delta">Δ</div><p>from absolute sound<br/>to production change</p>
      </div>
    </section>

    <section className="section" id="map">
      <div className="section-heading"><p className="kicker">FIELD MAP</p><h2>One field, connected tasks.</h2><p>The scope extends from individual effects to complete production systems. Each area will grow into a curated collection of projects, datasets and benchmarks.</p></div>
      <div className="area-grid">{areas.map((a,i)=><article className="area-card" key={a[1]}><div className="card-top"><span>{a[0]}</span>{i===4&&<small>FUTURE</small>}</div><h3>{a[1]}</h3><p>{a[2]}</p><div className="tags">{a[3].map(t=><span key={t}>{t}</span>)}</div></article>)}</div>
    </section>

    <section className="section resources" id="resources">
      <div className="section-heading compact"><p className="kicker">OPEN RESOURCES</p><h2>Start useful. Grow in public.</h2></div>
      <div className="resource-list">{resources.map((r,i)=><article className="resource-row" key={r[0]}><span className="resource-number">0{i+1}</span><div><h3>{r[0]}</h3><p>{r[3]}</p></div><span className="resource-type">{r[1]}</span><span className={`status ${r[2].toLowerCase()}`}>{r[2]}</span></article>)}</div>
    </section>

    <section className="section roadmap" id="roadmap">
      <div className="roadmap-copy"><p className="kicker">ROADMAP</p><h2>A foundation, not a finished catalogue.</h2><p>The first release focuses on a clear taxonomy and genuinely usable open-source resources. Benchmarks, reproducibility notes and new domains will be added as the field evolves.</p></div>
      <ol><li><span>NOW</span><strong>Define the landscape</strong><p>Taxonomy, project index and contribution format.</p></li><li><span>NEXT</span><strong>Make comparison easier</strong><p>Reproducibility fields, baselines and MixBench.</p></li><li><span>LATER</span><strong>Expand the production space</strong><p>Mastering, evaluation and spatial audio.</p></li></ol>
    </section>
    <footer id="about"><div><span className="mark">IA</span><p>Intelligent Audio Production<br/><small>A research initiative by Xinlu Liu.</small></p></div><p className="footer-note">A living, open resource for the audio research community.</p><a href="#top">Back to top ↑</a></footer>
  </main>;
}
